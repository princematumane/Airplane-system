<?php
   include("config.php");
   include("login.php");
   
   
   mysqli_close($db);
?>